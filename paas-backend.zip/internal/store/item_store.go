package store

import "paas-backend/internal/models"

var Items = []models.Item{
    {ID: "1", Name: "Item One", Price: 100},
    {ID: "2", Name: "Item Two", Price: 200},
}